// src/services/api.ts
import { HealthScore } from '../types';

const API_BASE_URL = 'http://localhost:8000/api';

export interface ValueStream {
  code: string;
  name: string;
}

export interface ValueStreamsResponse {
  value_streams: ValueStream[];
}

export type RagStatus = 'Red' | 'Amber' | 'Green' | 'Yellow';

export interface ValueStreamMetrics {
  vs_code: string;
  process_health: number;
  system_health: number;
  readiness_score: number;
  rag_status?: RagStatus;
  kpi_count?: number;     // Made optional with ?
  finding_count?: number;  // Made optional with ?
  painpoint_count?: number; // Made optional with ?
  value_at_stake_usd: number;
}

// Fetch all value streams
export const fetchValueStreams = async (): Promise<ValueStream[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/value-streams/`, {
      method: 'GET',
      headers: {
        'accept': 'application/json',
      }
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Failed to fetch value streams');
    }
    
    const data: ValueStreamsResponse = await response.json();
    return data.value_streams || []; // Extract the value_streams array
  } catch (error) {
    console.error('Error fetching value streams:', error);
    return [];
  }
};
// In src/services/api.ts
export const fetchHealthScores = async (vsCode: string | null): Promise<HealthScore[]> => {
  try {
    const url = vsCode 
      ? `${API_BASE_URL}/health-scores/${vsCode}`  // Changed from /?vs_code= to /{code}
      : `${API_BASE_URL}/health-scores/`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'accept': 'application/json',
      }
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Failed to fetch health scores');
    }

    const data = await response.json();
    return Array.isArray(data) ? data : [data]; // Handle both array and single object responses
  } catch (error) {
    console.error('Error fetching health scores:', error);
    throw error;
  }
};

// In api.ts
export interface KPI {
  vs_code: string;
  kpi_name: string;
  current_value: string;  // Changed to string to handle percentage values
  target_value: string;   // Changed to string to handle percentage values
  definition: string;
  target_direction: 'higher' | 'lower';
  current_numeric: number | null;
  target_numeric: number | null;
}

// Add this function to api.ts
// In api.ts
export const fetchKPIs = async (vsCode: string): Promise<KPI[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/kpis?vs_code=${vsCode}`);
    if (!response.ok) {
      throw new Error('Failed to fetch KPIs');
    }
    const data = await response.json();
    // Handle the nested kpis array in the response
    return Array.isArray(data.kpis) ? data.kpis : [];
  } catch (error) {
    console.error('Error fetching KPIs:', error);
    return []; // Return empty array on error
  }
};