Dataset bundle generated for ERP AI Health Assessment Hackathon.
