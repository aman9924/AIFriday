export interface HealthScore {
  vs_code: string;
  process_health: number;
  system_health: number;
  readiness_score: number;
  value_at_stake_usd: number;
  rag_status?: string;
  kpi_count?: number;
  finding_count?: number;
  painpoint_count?: number;
}