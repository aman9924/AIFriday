// src/components/UploadModal.tsx
import { X, Upload as UploadIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import React from 'react';
import '../styles/components.css';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  progress: number;
  onUpload: (file: File) => void;
}

const UploadModal = ({ isOpen, onClose, progress, onUpload }: UploadModalProps) => {
  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  return (
    <div className="modal-overlay">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="modal-content"
      >
        <div className="modal-header">
          <h2 className="modal-title">Upload ERP Data</h2>
          <button
            onClick={onClose}
            className="modal-close"
          >
            <X className="icon-sm" />
          </button>
        </div>

        <div className="modal-body">
          <div className="upload-area">
            <div className="upload-icon-container">
              <UploadIcon className="upload-icon" />
            </div>
            <p className="upload-text">Drag and drop files here</p>
            <p className="upload-subtext">CSV, Excel, or PDF files</p>
            
            <input
              type="file"
              id="file-upload"
              className="file-input"
              accept=".csv,.xlsx,.xls,.pdf"
              onChange={handleFileChange}
            />
            <label
              htmlFor="file-upload"
              className="file-label"
            >
              Select File
            </label>
          </div>

          {progress > 0 && (
            <div className="progress-container">
              <div className="progress-header">
                <span>Uploading...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
          )}

          <div className="modal-footer">
            <button
              onClick={onClose}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              className="btn btn-primary"
              disabled={progress < 100}
            >
              Analyze Data
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default UploadModal;