// src/services/api.ts
import { HealthScore } from '../types';

// Fetch all value streams
export const fetchValueStreams = async (): Promise<Array<{ vs_code: string; name: string }>> => {
  try {
    const response = await fetch('/api/value-streams');
    if (!response.ok) throw new Error('Failed to fetch value streams');
    return await response.json();
  } catch (error) {
    console.error('Error fetching value streams:', error);
    throw error;
  }
};

// Fetch health scores for a specific value stream
export const fetchHealthScores = async (vsCode: string | null): Promise<HealthScore[]> => {
  try {
    let url = null;
    if (vsCode == null) {
        url = '/api/health-scores';
    } else {
        url = `/api/health-scores/${vsCode}`
    }
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch health scores');
    return await response.json();
  } catch (error) {
    console.error('Error fetching health scores:', error);
    throw error;
  }
};