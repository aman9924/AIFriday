// src/pages/Reports.tsx
const Reports = () => {
  return (
    <div className="flex flex-col items-center justify-center h-64">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Reports</h2>
        <p className="text-slate-400">Coming Soon</p>
      </div>
    </div>
  );
};

export default Reports;