// src/pages/Insights.tsx
const Insights = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">AI-Generated Insights</h2>
      {/* Insights cards would go here */}
      <div className="text-center py-12 text-slate-500">
        Insights - Implementation in progress
      </div>
    </div>
  );
};

export default Insights;