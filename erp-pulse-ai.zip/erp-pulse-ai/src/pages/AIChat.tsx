import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Paperclip, X, Loader2, Languages } from 'lucide-react';
import { cn } from '../utils/cn';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const AIChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Español' },
    { code: 'fr', name: 'Français' },
    { code: 'de', name: 'Deutsch' },
    { code: 'hi', name: 'हिंदी' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Simulate AI response
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: `This is a simulated response to: "${input}" in ${languages.find(lang => lang.code === selectedLanguage)?.name}`,
        sender: 'ai',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    
    // Simulate file upload
    setTimeout(() => {
      const uploadMessage: Message = {
        id: Date.now().toString(),
        content: `File uploaded: ${file.name}`,
        sender: 'ai',
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, uploadMessage]);
      setIsUploading(false);
    }, 1500);
  };

  // return (
  //   <div className="ai-chat-container h-full">
      // <div className="chat-header">
      //   <div className="flex items-center">
      //     <div className="ai-avatar">
      //       <div className="ai-dot"></div>
      //       <div className="ai-dot delay-200"></div>
      //       <div className="ai-dot delay-400"></div>
      //     </div>
      //     <h2>ERP AI Assistant</h2>
      //   </div>
      //   <div className="language-selector">
      //     <button 
      //       onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
      //       className="language-button"
      //     >
      //       <Languages className="h-4 w-4" />
      //       <span>{languages.find(lang => lang.code === selectedLanguage)?.code.toUpperCase()}</span>
      //     </button>
      //     {showLanguageDropdown && (
      //       <div className="language-dropdown">
      //         {languages.map((lang) => (
      //           <button
      //             key={lang.code}
      //             onClick={() => {
      //               setSelectedLanguage(lang.code);
      //               setShowLanguageDropdown(false);
      //             }}
      //             className={cn(
      //               'language-option',
      //               selectedLanguage === lang.code && 'active'
      //             )}
      //           >
      //             {lang.name}
      //           </button>
      //         ))}
      //       </div>
      //     )}
      //   </div>
      // </div>

  //     <div className="chat-messages">
  //       {messages.length === 0 ? (
  //         <div className="empty-state">
  //           <div className="empty-icon">💡</div>
  //           <h3>How can I help you today?</h3>
  //           <p>Ask me anything about your ERP data or upload a file for analysis.</p>
  //         </div>
  //       ) : (
  //         <AnimatePresence>
  //           {messages.map((message) => (
  //             <motion.div
  //               key={message.id}
  //               className={cn(
  //                 'message',
  //                 message.sender === 'ai' ? 'ai-message' : 'user-message'
  //               )}
  //               initial={{ opacity: 0, y: 20 }}
  //               animate={{ opacity: 1, y: 0 }}
  //               exit={{ opacity: 0, x: message.sender === 'user' ? 100 : -100 }}
  //               transition={{ duration: 0.3 }}
  //             >
  //               <div className="message-content">
  //                 {message.content}
  //                 <div className="message-time">
  //                   {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
  //                 </div>
  //               </div>
  //             </motion.div>
  //           ))}
  //           <div ref={messagesEndRef} />
  //         </AnimatePresence>
  //       )}
  //     </div>

  //     {/* <form onSubmit={handleSendMessage} className="chat-input-container">
  //       <div className="file-upload">
  //         <input
  //           type="file"
  //           id="file-upload"
  //           className="hidden"
  //           onChange={handleFileUpload}
  //           disabled={isUploading}
  //         />
  //         <label htmlFor="file-upload" className="upload-button">
  //           {isUploading ? (
  //             <Loader2 className="h-5 w-5 animate-spin" />
  //           ) : (
  //             <Paperclip className="h-5 w-5" />
  //           )}
  //         </label>
  //       </div>
  //       <input
  //         type="text"
  //         value={input}
  //         onChange={(e) => setInput(e.target.value)}
  //         placeholder={`Message in ${languages.find(lang => lang.code === selectedLanguage)?.name}...`}
  //         className="chat-input"
  //         disabled={isLoading}
  //       />
  //       <button
  //         type="submit"
  //         className="send-button"
  //         disabled={!input.trim() || isLoading}
  //       >
  //         {isLoading ? (
  //           <Loader2 className="h-5 w-5 animate-spin" />
  //         ) : (
  //           <Send className="h-5 w-5" />
  //         )}
  //       </button>
  //     </form> */}

  //     {/* Add this above the form */}
  //     <div className="px-4 pt-2">
  //       {isLoading && (
  //         <div className="typing-indicator">
  //           <span>AI is typing</span>
  //           <span className="typing-dot"></span>
  //           <span className="typing-dot"></span>
  //           <span className="typing-dot"></span>
  //         </div>
  //       )}
        
  //       {/* Example suggestions (you can make these dynamic) */}
  //       <div className="suggestions-container">
  //         <button className="suggestion-chip">Show me sales data</button>
  //         <button className="suggestion-chip">Analyze last quarter</button>
  //         <button className="suggestion-chip">Generate report</button>
  //       </div>
  //     </div>

  //     <form onSubmit={handleSendMessage} className="chat-input-container">
  //       <div className="input-wrapper">
  //         <input
  //           type="text"
  //           value={input}
  //           onChange={(e) => setInput(e.target.value)}
  //           placeholder={`Message in ${languages.find(lang => lang.code === selectedLanguage)?.name}...`}
  //           className="chat-input"
  //           disabled={isLoading}
  //           onKeyDown={(e) => {
  //             if (e.key === 'Enter' && !e.shiftKey) {
  //               e.preventDefault();
  //               handleSendMessage(e);
  //             }
  //           }}
  //         />
  //         <div className="input-actions">
  //           <div className="file-upload">
  //             <input
  //               type="file"
  //               id="file-upload"
  //               className="hidden"
  //               onChange={handleFileUpload}
  //               disabled={isUploading}
  //             />
  //             <label htmlFor="file-upload" className="upload-button">
  //               {isUploading ? (
  //                 <Loader2 className="h-4 w-4 animate-spin" />
  //               ) : (
  //                 <Paperclip className="h-4 w-4" />
  //               )}
  //             </label>
  //           </div>
            
  //           {/* Add emoji picker button (you'll need to implement the emoji picker functionality) */}
  //           <button type="button" className="emoji-button">
  //             <span role="img" aria-label="Emoji">😊</span>
  //           </button>
            
  //           <button
  //             type="submit"
  //             className="send-button"
  //             disabled={!input.trim() || isLoading}
  //           >
  //             {isLoading ? (
  //               <Loader2 className="h-4 w-4 animate-spin" />
  //             ) : (
  //               <Send className="h-4 w-4" />
  //             )}
  //           </button>
  //         </div>
  //       </div>
  //     </form>
  //   </div>
  // );

  return (
    <div className="ai-chat-container">
      {/* <div className="chat-header">
        <div className="flex items-center">
          <div className="ai-avatar">
            <div className="ai-dot"></div>
            <div className="ai-dot delay-200"></div>
            <div className="ai-dot delay-400"></div>
          </div>
          <h2>ERP AI Assistant</h2>
        </div>
        <div className="language-selector">
          <button 
            onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
            className="language-button"
          >
            <Languages className="h-4 w-4" />
            <span>{languages.find(lang => lang.code === selectedLanguage)?.code.toUpperCase()}</span>
          </button>
          {showLanguageDropdown && (
            <div className="language-dropdown">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setSelectedLanguage(lang.code);
                    setShowLanguageDropdown(false);
                  }}
                  className={cn(
                    'language-option',
                    selectedLanguage === lang.code && 'active'
                  )}
                >
                  {lang.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div> */}
      <div className="chat-messages">
        <div className="messages-container">
          {messages.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">💡</div>
              <h3>How can I help you today?</h3>
              <p>Ask me anything about your ERP data or upload a file for analysis.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    className={cn(
                      'message',
                      message.sender === 'ai' ? 'ai-message' : 'user-message'
                    )}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="message-content">
                      {message.content}
                      <div className="message-time">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Suggestions and typing indicator */}
      <div className="suggestions-wrapper">
        {isLoading && (
          <div className="typing-indicator">
            <span>AI is typing</span>
            <span className="typing-dot"></span>
            <span className="typing-dot"></span>
            <span className="typing-dot"></span>
          </div>
        )}
        
         <div className="suggestions-container">
            <button 
              className="suggestion-chip"
              onClick={() => setInput(prev => prev + "Show me sales data")}
            >
              Show me sales data
            </button>
            <button 
              className="suggestion-chip"
              onClick={() => setInput(prev => prev + "Analyze last quarter")}
            >
              Analyze last quarter
            </button>
            <button 
              className="suggestion-chip"
              onClick={() => setInput(prev => prev + "Generate report")}
            >
              Generate report
            </button>
          </div>
      </div>

      {/* Input container - fixed at bottom */}
      <div className="chat-input-container">
        <div className="input-outer-wrapper">
          <form onSubmit={handleSendMessage} className="input-wrapper">
            <div className="input-actions-left">
              <div className="language-selector">
                <button 
                  onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
                  className="language-button"
                >
                  <Languages className="h-4 w-4" />
                  <span>{languages.find(lang => lang.code === selectedLanguage)?.code.toUpperCase()}</span>
                </button>
                {showLanguageDropdown && (
                  <div className="language-dropdown">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setSelectedLanguage(lang.code);
                          setShowLanguageDropdown(false);
                        }}
                        className={cn(
                          'language-option',
                          selectedLanguage === lang.code && 'active'
                        )}
                      >
                        {lang.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Message in ${languages.find(lang => lang.code === selectedLanguage)?.name}...`}
              className="chat-input"
              disabled={isLoading}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
            />
            <div className="input-actions">
              <div className="file-upload">
                <input
                  type="file"
                  id="file-upload"
                  className="hidden"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                />
                <label htmlFor="file-upload" className="upload-button">
                  {isUploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Paperclip className="h-4 w-4" />
                  )}
                </label>
              </div>
              
              <button
                type="submit"
                className="send-button"
                disabled={!input.trim() || isLoading}
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AIChat;