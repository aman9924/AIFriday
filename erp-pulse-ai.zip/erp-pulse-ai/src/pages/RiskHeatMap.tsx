// src/pages/RiskHeatmap.tsx
const RiskHeatmap = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-1">Risk Heatmap</h2>
        <p className="text-slate-400">Click any cell for detailed analysis</p>
      </div>
      {/* Heatmap implementation would go here */}
      <div className="text-center py-12 text-slate-500">
        Risk Heatmap - Implementation in progress
      </div>
    </div>
  );
};

export default RiskHeatmap;