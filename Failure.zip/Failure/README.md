\# 1. Run setup

python main.py setup



\# 2. Start API

python main.py api

# 3. Start UI

python main.py ui

