"""Test citation feature in LLM responses."""

from llm_copilot import LLMCopilot

# Initialize copilot
print("Initializing copilot...")
copilot = LLMCopilot()
copilot.initialize()

# Ask a question
print("\n" + "="*60)
print("Testing Citation Feature")
print("="*60)

question = "What is the current DSO for Order to Cash?"
print(f"\nQuestion: {question}\n")

result = copilot.ask(question, vs_code="O2C")

print("ANSWER:")
print("-" * 60)
print(result.get("answer", "No answer"))

print("\n\nSOURCES REFERENCED:")
print("-" * 60)
citations = result.get("citations", [])
if citations:
    for citation in citations:
        print(f"[{citation['index']}] {citation['citation']}")
        print(f"    Type: {citation['type']} | VS: {citation['vs_code']}")
        print()
else:
    print("No citations found")

print("\nSources used:", result.get("sources_used", 0))
print("Model:", result.get("model", "Unknown"))
