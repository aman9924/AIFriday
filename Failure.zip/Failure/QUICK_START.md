# 🚀 Quick Start Guide - ZeroRisk ERP Health Check

## ✅ **System is Ready!**

### **What Was Fixed:**
1. ✅ Migrated from Claude to TCS GenAI Lab API
2. ✅ Fixed SSL certificate verification issues  
3. ✅ Implemented source citations to prevent hallucinations
4. ✅ API server ready on port 8000
5. ✅ Streamlit UI ready on port 8501

---

## 🏃 **Run Your Application**

### **Option 1: Start API Server**
```bash
python main.py api
```
- **Access:** http://localhost:8000
- **Test:** http://localhost:8000/health
- **API Docs:** http://localhost:8000/docs

### **Option 2: Start Streamlit UI**
```bash
python main.py ui
```
- **Access:** http://localhost:8501
- **Features:** Dashboard, Chat with AI, KPI Explorer

### **Option 3: Run Both**
```bash
python main.py all
```
Runs setup + starts both services

---

## 🧪 **Test the Citation Feature**

```bash
python test_citations.py
```

**You should see:**
- ✅ Question about DSO for O2C
- ✅ Answer with citations [1], [2], [3]...
- ✅ "Sources Referenced:" section
- ✅ Full citation metadata

---

## 💡 **Key Features**

### **1. Ask Questions with Citations**
```bash
curl -X POST http://localhost:8000/api/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What are the critical risks in Order to Cash?", "vs_code": "O2C"}'
```

**Response includes:**
```json
{
  "answer": "According to [1], the DSO is 52 days...",
  "sources_used": 5,
  "citations": [
    {
      "index": 1,
      "citation": "Source: Crystallus KPI Report - O2C",
      "type": "kpi",
      "vs_code": "O2C"
    }
  ]
}
```

### **2. View Health Scores**
- **Dashboard:** http://localhost:8501
- **API:** http://localhost:8000/api/health-scores

### **3. Chat with AI Copilot**
- Open UI at http://localhost:8501
- Navigate to "🤖 AI Copilot"
- Ask questions - citations shown below each answer!

---

## 📊 **What's Being Analyzed**

Your system ingests **5 source documents**:

1. **TCS Crystallus Process Insights.xlsx** - KPI metrics
2. **ERP Health Check Reports.docx** - Technical findings
3. **Business Value Streams.docx** - Process flows
4. **S/4HANA Simplification Items.pdf** - Migration complexity
5. **Pharma Benchmarks.docx** - Industry standards

**Value Streams Tracked:**
- O2C (Order to Cash)
- P2P (Procure to Pay)
- P2M (Plan to Manufacture)
- R2R (Record to Report)
- H2R (Hire to Retire)
- A2D (Acquire to Decommission)
- DM (Data Management)

---

## 🔧 **Troubleshooting**

### **Port Already in Use**
```bash
# Windows PowerShell
netstat -ano | findstr :8000
taskkill /F /PID <process_id>
```

### **Re-run Setup**
If data needs to be refreshed:
```bash
python main.py setup
```

This will:
1. Re-ingest all source documents
2. Recalculate health scores
3. Rebuild vector index with citations

---

## 📚 **Citation System**

### **How It Works:**
1. Every document chunk has citation metadata
2. LLM is instructed to cite all sources using [1], [2], etc.
3. API returns structured citation data
4. UI displays citations below answers

### **Example:**
**Question:** "What is the current DSO?"

**Answer:**
> "The current DSO is **52 days** [1], compared to the target of **45 days** [1] and the pharma benchmark of **45 days** [4]."

**Sources:**
- [1] Crystallus KPI Report - O2C
- [4] Pharmaceutical Industry Benchmarks

---

## ✨ **Next Steps**

1. **Explore the Dashboard**
   - Visit http://localhost:8501
   - Check health scores for each value stream
   - View RAG status (Red/Amber/Green)

2. **Ask Questions**
   - Use the AI Copilot chat
   - Try: "What are quick wins?"
   - Try: "Analyze P2P health"
   - Try: "Show risks in R2R"

3. **Review Citations**
   - Expand "📚 View Sources" below each answer
   - Verify all claims are source-backed

---

## 📖 **Documentation**

- **Full Details:** See `IMPLEMENTATION_SUMMARY.md`
- **API Docs:** http://localhost:8000/docs (when API running)
- **User Guide:** See `README.md`

---

**🎉 Your system is ready to use! Enjoy exploring with AI-powered insights and source-backed analysis!**
